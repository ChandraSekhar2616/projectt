package com.pos.controller;

import java.util.List;
import java.util.Optional;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pos.model.Product;
import com.pos.service.ProductService;

;

@RestController
@RequestMapping("API/products")
public class ProductController {

    private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private ProductService productService;
   
    
    @GetMapping
    public List<Product> getAllProducts() {
        logger.info("Fetching all products");
        return productService.getAllProducts();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        logger.info("Fetching product with ID: {}", id);
        Optional<Product> product = productService.getProductById(id);
        return product.map(ResponseEntity::ok)
                    .orElse(null);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product productDetails) {
        logger.info("Updating product with ID: {}", id);
        Product updatedProduct = productService.getProductById(id)
                    .map(product -> {
                        product.setName(productDetails.getName());
                        product.setBrand(productDetails.getBrand());
                        product.setMadein(productDetails.getMadein());
                        product.setPrice(productDetails.getPrice());
                        return productService.saveProduct(product);
                    })
                    .orElse(null);
        return ResponseEntity.ok(updatedProduct);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteProduct(@PathVariable Long id) {
        logger.info("Deleting product with ID: {}", id);
        return productService.getProductById(id)
                    .map(product -> {
                        productService.deleteProduct(id);
                        return ResponseEntity.noContent().build();
                    })
                    .orElseThrow();
    }

}
