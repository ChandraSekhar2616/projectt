package com.pos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PosBillingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PosBillingApplication.class, args);
	System.out.println("WELCOME TO BOOT");
	}

}
